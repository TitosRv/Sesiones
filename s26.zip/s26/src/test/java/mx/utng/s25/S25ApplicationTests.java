package mx.utng.s25;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class S25ApplicationTests {

	@Test
	void contextLoads() {
	}

}

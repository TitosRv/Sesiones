package mx.utng.s31;

@FunctionalInterface
public interface StringToInteger {
    
    Integer convertir(String s);
}

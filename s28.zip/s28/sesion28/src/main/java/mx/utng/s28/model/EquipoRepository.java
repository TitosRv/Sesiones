package mx.utng.s28.model;

public class EquipoRepository extends CrudRepository{
    
}
